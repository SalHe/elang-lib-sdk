#include "PeLoader_Lib.h"

EXTERN_C VOID PeLoader_LoadLibrary (PMDATA_INF pRetData, INT nArgCount, PMDATA_INF pArgInf)
{
	LPBYTE pLibData = (LPBYTE)(pArgInf[0].m_pBin+sizeof(DWORD)*2);
	pRetData->m_int = (DWORD)(_LoadLibrary(pLibData,(FRCALLBACK)(pArgInf[1].m_pdwSubCodeAdr),pArgInf[2].m_int));
}

EXTERN_C VOID PeLoader_GetProcAddress (PMDATA_INF pRetData, INT nArgCount, PMDATA_INF pArgInf)
{
	switch (pArgInf[1].m_dtDataType)
	{
	case SDT_INT:
		pRetData->m_int = (DWORD)(_GetProcAddress((LPBYTE)(pArgInf[0].m_int),(LPCSTR)(pArgInf[1].m_int)));
		break;
	case SDT_INT|DT_IS_VAR:
		pRetData->m_int = (DWORD)(_GetProcAddress((LPBYTE)(pArgInf[0].m_int),(LPCSTR)(*(pArgInf[1].m_pInt))));
		break;
	case SDT_TEXT:
		pRetData->m_int = (DWORD)(_GetProcAddress((LPBYTE)(pArgInf[0].m_int),pArgInf[1].m_pText));
		break;
	case SDT_TEXT|DT_IS_VAR:
		pRetData->m_int = (DWORD)(_GetProcAddress((LPBYTE)(pArgInf[0].m_int),*(pArgInf[1].m_ppText)));
		break;
	case SDT_BIN:	
		pRetData->m_int = (DWORD)_GetProcAddress((LPBYTE)(pArgInf[0].m_int),(LPCSTR)(pArgInf[1].m_pBin+sizeof(DWORD)*2));
		break;
	case SDT_BIN|DT_IS_VAR:
		pRetData->m_int = (DWORD)_GetProcAddress((LPBYTE)(pArgInf[0].m_int),(LPCSTR)(*(pArgInf[1].m_ppBin)+sizeof(DWORD)*2));
		break;
	}
}

EXTERN_C VOID PeLoader_FreeLibrary (PMDATA_INF pRetData, INT nArgCount, PMDATA_INF pArgInf)
{
	pRetData->m_bool = _FreeLibrary((LPBYTE)(pArgInf[0].m_int));
}

EXTERN_C VOID PeLoader_GetEntryPoint (PMDATA_INF pRetData, INT nArgCount, PMDATA_INF pArgInf)
{
	pRetData->m_int = _GetEntryPoint((LPBYTE)(pArgInf[0].m_int));
}

EXTERN_C VOID PeLoader_Call (PMDATA_INF pRetData, INT nArgCount, PMDATA_INF pArgInf)
{
	DWORD dwAddress = pArgInf[0].m_int,
		xData,dwRet_l,dwRet_h;

	//
	//	ѭ��ѹջ
	//
	for (int i=nArgCount-1;i>1;i--)
	{

		switch (pArgInf[i].m_dtDataType)	//	�жϲ�������
		{

		case SDT_BYTE:	//	�ֽ��� ( 8λ )
			xData = pArgInf[i].m_byte;
			break;

		case SDT_SHORT:	//	�������� ( 16λ )
			xData = pArgInf[i].m_short;
			break;

		case SDT_INT:	//	������ ( 32λ )
			xData = pArgInf[i].m_int;
			break;

		case SDT_INT64:	//	�������� ( 64λ )
			xData = *(PDWORD)(((PCHAR)(&(pArgInf[i].m_int64))+sizeof(DWORD)));	//	��32λ
			_asm
			{
				push xData	//	����ѹջ
			}
			xData = *(PDWORD)(&(pArgInf[i].m_int64));	//	��32λ
			break;

		case SDT_FLOAT:	//	С���� ( 32λ )
			xData = pArgInf[i].m_uint;
			break;

		case SDT_DOUBLE:	//	˫����С���� ( 64λ )
			xData = *(PDWORD)(((PCHAR)(&(pArgInf[i].m_double))+sizeof(DWORD)));	//	��32λ
			_asm
			{
				push xData	//	����ѹջ
			}
			xData = *(PDWORD)(&(pArgInf[i].m_double));	//	��32λ
			break;

		case SDT_BOOL:	//	�߼��� ( 32λ )
			xData = pArgInf[i].m_bool;
			break;

		case SDT_DATE_TIME:	//	ʱ�������� ( 64λ )
			xData = *(PDWORD)(((PCHAR)(&(pArgInf[i].m_date))+sizeof(DWORD)));	//	��32λ
			_asm
			{
				push xData	//	����ѹջ
			}
			xData = *(PDWORD)(&(pArgInf[i].m_date));	//	��32λ
			break;

		case SDT_TEXT:	//	�ı��� ( 32λ )
			xData = (DWORD)(pArgInf[i].m_pText);
			break;

		case SDT_BIN:	//	�ֽڼ��� ( 32λ )
			xData = (DWORD)(pArgInf[i].m_pBin+sizeof(DWORD)*2);
			break;

		case SDT_SUB_PTR:	//	�ӳ���ָ���� ( 32λ )
			xData = pArgInf[i].m_dwSubCodeAdr;
			break;

		default:	//	��֧�ֵ�����
			xData = 0;
			break;
		}
		
		_asm
		{
			push xData	//	����ѹջ
		}

	}	//	ѭ��ѹջ����


	//
	//	����ָ����ַ���Ĵ��� ( �ӳ��� )
	//
	_asm
	{
		call dwAddress	//	����
		mov dwRet_l,eax	//	����ֵ ( ��32λ )
		mov dwRet_h,edx	//	����ֵ ( ��32λ )
	}


	//
	//	�жϽ��շ���ֵ�ı�������, ������ֵ��ֵ���˱���
	//
	switch (pArgInf[1].m_dtDataType)
	{

	case SDT_BYTE:	//	�ֽ��� ( 8λ )
		if (pArgInf[1].m_pByte)
			*pArgInf[1].m_pByte = (BYTE)dwRet_l;
		break;

	case SDT_SHORT:	//	�������� ( 16λ )
		if (pArgInf[1].m_pShort)
			*pArgInf[1].m_pShort = (SHORT)dwRet_l;
		break;

	case SDT_INT:	//	������ ( 32λ )
		if (pArgInf[1].m_pInt)
			*(PDWORD)pArgInf[1].m_pInt = dwRet_l;
		break;

	case SDT_INT64:	//	�������� ( 64λ )
		if (pArgInf[1].m_pInt64)
		{
			*(PDWORD)(pArgInf[1].m_pInt64) = dwRet_l;	//	��32λ
			*(PDWORD)(((PCHAR)pArgInf[1].m_pInt64)+sizeof(DWORD)) = dwRet_h;	//	��32λ
		}
		break;

	case SDT_FLOAT:	//	С���� ( 32λ )
		if (pArgInf[1].m_pFloat)
			*pArgInf[1].m_pFloat = (FLOAT)dwRet_l;
		break;

	case SDT_DOUBLE:	//	˫����С���� ( 64λ )
		if (pArgInf[1].m_pDouble)
		{
			*(PDWORD)pArgInf[1].m_pDouble = dwRet_l;	//	��32λ
			*(PDWORD)(((PCHAR)pArgInf[1].m_pDouble)+sizeof(DWORD)) = dwRet_h;	//	��32λ
		}
		break;

	case SDT_BOOL:	//	�߼��� ( 32λ )
		if (pArgInf[1].m_pBool)
			*pArgInf[1].m_pBool = (BOOL)dwRet_l;
		break;

	case SDT_DATE_TIME:	//	����ʱ���� ( 64λ )
		if (pArgInf[1].m_pDate)
		{
			*(PDWORD)pArgInf[1].m_pDate = dwRet_l;	//	��32λ
			*(PDWORD)(((PCHAR)pArgInf[1].m_pDate)+sizeof(DWORD)) = dwRet_h;	//	��32λ
		}
		break;

	case SDT_TEXT:	//	�ı��� ( 32λ )
		if (pArgInf[1].m_ppText)
		{
			PeLoader_MFree (*(pArgInf[1].m_ppText));	//	�ͷ�֮ǰ���ڴ�
			
			*(pArgInf[1].m_ppText) = 
				PeLoader_CloneTextData((LPSTR)dwRet_l);	//	����һ��E���ı�������
		}
		break;

	case SDT_BIN:	//	�ֽڼ��� ( 32λ )
		if (pArgInf[1].m_ppBin)
		{
			PeLoader_MFree (*(pArgInf[1].m_ppBin));	//	�ͷ�֮ǰ���ڴ�

			*(pArgInf[1].m_ppBin) = PeLoader_CloneBinData(	//	����һ��E���ֽڼ�����
				(LPBYTE)dwRet_l,*(PDWORD)(((LPBYTE)dwRet_l)-sizeof(DWORD)));
		}
		break;

	case SDT_SUB_PTR:	//	�ӳ���ָ���� ( 32λ )
		if (pArgInf[1].m_pdwSubCodeAdr)
			*pArgInf[1].m_pdwSubCodeAdr = dwRet_l;
		break;
	}
}

////////////////////////////////////////////////////////////////////////////


#ifndef __E_STATIC_LIB

PLIB_INFO WINAPI GetNewInf ()
{
	return &s_LibInfo;
}

#endif

INT WINAPI PeLoader_NotifySys (INT nMsg, DWORD dwParam1, DWORD dwParam2)
{
	if (PeLoader_g_fnNotifySys)
		return PeLoader_g_nLastNotifyResult = PeLoader_g_fnNotifySys (nMsg, dwParam1, dwParam2);
	else
		return PeLoader_g_nLastNotifyResult = 0;
}


INT WINAPI _PeLoader_ProcessNotifyLib (INT nMsg, DWORD dwParam1, DWORD dwParam2)
{
	INT nRet = NR_OK;
	switch (nMsg)
	{
	case NL_SYS_NOTIFY_FUNCTION:
		PeLoader_g_fnNotifySys = (PFN_NOTIFY_SYS)dwParam1;
		break;
	default:
		nRet = NR_ERR;
		break;
	}

	return nRet;
}

EXTERN_C INT WINAPI PeLoader_ProcessNotifyLib (INT nMsg, DWORD dwParam1, DWORD dwParam2)
{
#ifndef __E_STATIC_LIB
	if(nMsg == NL_GET_CMD_FUNC_NAMES)
		return (INT) g_CmdNames;
	else if(nMsg == NL_GET_NOTIFY_LIB_FUNC_NAME)
		return (INT) "PeLoader_ProcessNotifyLib";
	else if(nMsg == NL_GET_DEPENDENT_LIBS)
		return NULL;
#endif
	return _PeLoader_ProcessNotifyLib(nMsg, dwParam1, dwParam2);
}

//
//	ʹ��ָ���ı����ݽ����׳�����ʹ�õ��ı����ݡ�
//
LPSTR WINAPI PeLoader_CloneTextData (LPSTR ps)
{
    if (!ps)
        return NULL;
	if (*ps == '\0')
		return NULL;

    INT nTextLen = strlen (ps);
    char* pd = (char*)PeLoader_NotifySys (NRS_MALLOC,
		(DWORD)(nTextLen + 1), 0);
	if (pd)
	{
		memcpy (pd, ps, nTextLen);
		pd [nTextLen] = '\0';
	}
    return pd;
}

//
//	ʹ��ָ�����ݽ����׳�����ʹ�õ��ֽڼ����ݡ�
//
LPBYTE WINAPI PeLoader_CloneBinData (LPBYTE pData, INT nDataSize)
{
	LPBYTE pd = NULL;

    if (nDataSize > 0)
	{
		pd = (LPBYTE)PeLoader_NotifySys (NRS_MALLOC, 
			(DWORD)(sizeof (INT) * 2 + nDataSize), 0);
		if (pd)
		{
			*(LPINT)pd = 1;
			*(LPINT)(pd + sizeof (INT)) = nDataSize;
			memcpy (pd + sizeof (INT) * 2, pData, nDataSize);
		}
	}

	return pd;
}

//
//	�ͷ��ڴ�
//
VOID WINAPI PeLoader_MFree(PVOID p)
{
	if (p)
		PeLoader_NotifySys (NRS_MFREE,(DWORD)p, 0);
}