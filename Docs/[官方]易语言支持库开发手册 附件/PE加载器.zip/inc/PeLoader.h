#include <Windows.h>

#define MAX(a,b) (a>b?a:b)

typedef int (APIENTRY *DLLMAIN)(HMODULE hModule,DWORD  ul_reason_for_call,LPVOID lpReserved);
typedef int (APIENTRY *WINMAIN)(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nShowCmd);
typedef DWORD (WINAPI *FRCALLBACK)(LPCSTR pModuleName,LPCSTR pProcName,DWORD pFR_lParam);

//
//	�ڲ�����
//
LPVOID VirAlloc(LPVOID LpAddress,SIZE_T DwSize);
BOOL VirFree(LPVOID LpAddress);
UINT GetAlignedSize(UINT Origin,UINT Alignment);
VOID DoRelocation(DWORD NewBase);
BOOL FillRavAddress(DWORD ImageBase,FRCALLBACK pFR_CallBack,DWORD pFR_lParam);


//
//	��������
//
LPBYTE WINAPI _LoadLibrary(LPBYTE LpLibData,FRCALLBACK pFR_CallBack,DWORD pFR_lParam);
BOOL WINAPI _FreeLibrary(LPBYTE hLibModule);
FARPROC WINAPI _GetProcAddress(LPBYTE hLibModule,LPCSTR lpProcName);
DWORD WINAPI _GetEntryPoint(LPBYTE hLibModule);