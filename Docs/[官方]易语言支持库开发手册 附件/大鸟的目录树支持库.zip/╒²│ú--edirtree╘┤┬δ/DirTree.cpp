// DirTree.cpp : implementation file
//

#include "stdafx.h"
#include "eDirTree.h"
#include "DirTree.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

INT WINAPI NotifySys (INT nMsg, DWORD dwParam1, DWORD dwParam2 = 0);



/////////////////////////////////////////////////////////////////////////////
// CDirTree dialog


CDirTree::CDirTree(CWnd* pParent /*=NULL*/)
	: CDialog(CDirTree::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDirTree)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDirTree::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDirTree)
	DDX_Control(pDX, IDC_TREE1, m_Tree);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDirTree, CDialog)
	//{{AFX_MSG_MAP(CDirTree)
	ON_WM_SIZE()
	ON_MESSAGE(WU_GET_WND_PTR, OnGetWndPtr)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDirTree message handlers

void CDirTree::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	CDialog::PostNcDestroy();
	NotifySys(NRS_UNIT_DESTROIED,m_Tree.m_dwWinFormID,m_Tree.m_dwUnitID);
	//��ɾ��
	delete this;
}

void CDirTree::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	m_Tree.MoveWindow (0,0,cx,cy);
}
LRESULT CDirTree::OnGetWndPtr(WPARAM wparam, LPARAM lparam)
{


	return (LRESULT)this;
}

/*void CDirTree::OnDblclkTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	NotifySys (NRS_EVENT_NOTIFY, (DWORD)&EVENT_NOTIFY (m_Tree.m_dwWinFormID, m_Tree.m_dwUnitID, 1));

	*pResult = 0;
}

void CDirTree::OnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here


   LPFOLDERNODE  lpfn = (LPFOLDERNODE)m_Tree.GetItemData(pNMTreeView->itemNew.hItem);

   BOOL b_NonFolder=!(lpfn->dwAttributes & SFGAO_FOLDER);
	EVENT_NOTIFY event (m_Tree.m_dwWinFormID, m_Tree.m_dwUnitID, 0);
	event.m_nArgCount = 1;
	event.m_nArgValue [0] = b_NonFolder;
	NotifySys (NRS_EVENT_NOTIFY, (DWORD)&event);
	
	*pResult = 0;
}
*/



