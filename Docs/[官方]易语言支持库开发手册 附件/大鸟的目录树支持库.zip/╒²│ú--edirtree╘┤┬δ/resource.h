//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by eDirTree.rc
//
#define IDB_BITMAP1                     1314121
#define IDB_BITMAP2                     1314122
#define ID_MENUITEM32771                1314123
#define ID_MENUITEM32772                1314124

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        11004
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         11001
#define _APS_NEXT_SYMED_VALUE           11002
#endif
#endif
