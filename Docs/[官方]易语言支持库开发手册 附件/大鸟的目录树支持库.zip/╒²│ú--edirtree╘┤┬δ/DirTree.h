#if !defined(AFX_DIRTREE_H__0F305647_24BE_4596_81ED_D647FEB336D0__INCLUDED_)
#define AFX_DIRTREE_H__0F305647_24BE_4596_81ED_D647FEB336D0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DirTree.h : header file
//

#include "ShellFolderView.h"


/////////////////////////////////////////////////////////////////////////////
// CDirTree dialog

class CDirTree : public CDialog
{
// Construction
public:
	CDirTree(CWnd* pParent = NULL);   // standard constructor


	LRESULT OnGetWndPtr(WPARAM wparam, LPARAM lparam);



// Dialog Data
	//{{AFX_DATA(CDirTree)
	enum { IDD = IDD_DIRTREE_DIALOG };
	CShellFolderView	m_Tree;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDirTree)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDirTree)
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIRTREE_H__0F305647_24BE_4596_81ED_D647FEB336D0__INCLUDED_)
