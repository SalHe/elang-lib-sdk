#if !defined(AFX_EAGENT_H__AAE87E0B_6B5E_4E09_8203_770FA2DF7A56__INCLUDED_)
#define AFX_EAGENT_H__AAE87E0B_6B5E_4E09_8203_770FA2DF7A56__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// eAgent.h : header file
//


#include "lib.h"
#include "untshare.h"
#include "agtsvr.h"

#include <afxctl.h>//������AfxConnectionAdvise��AfxConnectionUnadvise�Ⱥ���,�Ȼ����ӵ��¼�ԴʱҪ�õ�

#define CUR_UNIT_VER		1

class AgentNotifySink : public IAgentNotifySinkEx {
public:
	AgentNotifySink() : m_cRefs(0) {}
   ~AgentNotifySink() {}

		STDMETHODIMP QueryInterface(REFIID, LPVOID FAR *);
		STDMETHODIMP_(ULONG) AddRef();
		STDMETHODIMP_(ULONG) Release();

		STDMETHODIMP GetTypeInfoCount(UINT *);
		STDMETHODIMP GetTypeInfo(UINT, LCID, ITypeInfo **);
		STDMETHODIMP GetIDsOfNames(REFIID, OLECHAR **, UINT, LCID, DISPID *);
		STDMETHODIMP Invoke(DISPID, REFIID, LCID, WORD, DISPPARAMS *, VARIANT *, EXCEPINFO *, UINT *);

		virtual STDMETHODIMP Command(long dwCommandID, IUnknown * punkUserInput);
		virtual STDMETHODIMP ActivateInputState(long dwCharID, long bActivated);
		virtual STDMETHODIMP Restart();
		virtual STDMETHODIMP Shutdown();
		virtual STDMETHODIMP VisibleState(long dwCharID, long bVisible, long lCause);
		virtual STDMETHODIMP Click(long dwCharID, short fwKeys, long x, long y);
		virtual STDMETHODIMP DblClick(long dwCharID, short fwKeys, long x, long y);
		virtual STDMETHODIMP DragStart(long dwCharID, short fwKeys, long x, long y);
		virtual STDMETHODIMP DragComplete(long dwCharID, short fwKeys, long x, long y);
		virtual STDMETHODIMP RequestStart(long dwRequestID);
		virtual STDMETHODIMP RequestComplete(long dwRequestID, long hrStatus);
		virtual STDMETHODIMP BookMark(long dwBookMarkID);
		virtual STDMETHODIMP Idle(long dwCharID, long bStart);
		virtual STDMETHODIMP Move(long dwCharID, long x, long y, long lCause);
		virtual STDMETHODIMP Size(long dwCharID, long lWidth, long lHeight);
		virtual STDMETHODIMP BalloonVisibleState(long dwCharID, long bVisible);

		virtual STDMETHODIMP HelpComplete(long dwCharID, long dwCommandID, long dwCause);
		virtual STDMETHODIMP ListeningState(long dwCharacterID, long bListenState, long dwCause);
		virtual STDMETHODIMP DefaultCharacterChange(BSTR bszGUID);
		virtual STDMETHODIMP AgentPropertyChange();
		virtual STDMETHODIMP ActiveClientChange(long dwCharID, long lStatus);

		DWORD m_dwWinFormID, m_dwUnitID;
private:

	ULONG	m_cRefs;
};

class CPIeAgent : public CPropertyInfo
{
public:
	long m_Top;
	long m_Left;
	long m_Width;
	long m_Height;
    BOOL SoundOn;
    BOOL MenuOn;

public:
	CPIeAgent ()  { }

	virtual void init ();
	virtual BOOL Serialize (CArchive& ar);
};


extern "C"
PFN_INTERFACE WINAPI emsagent_GetInterface_eMsAgent (INT nInterfaceNO);

HUNIT WINAPI Create_eAgent (LPBYTE pAllData, INT nAllDataSize,
		DWORD dwStyle, HWND hParentWnd, UINT uID, HMENU hMenu, INT x, INT y, INT cx, INT cy,
		DWORD dwWinFormID, DWORD dwUnitID, HWND hDesignWnd = 0, BOOL blInDesignMode = FALSE);
BOOL WINAPI NotifyPropertyChanged_eAgent (HUNIT hUnit, INT nPropertyIndex,
		PUNIT_PROPERTY_VALUE pPropertyVaule, LPTSTR* ppszTipText);
BOOL WINAPI GetPropertyData_eAgent (HUNIT hUnit, INT nPropertyIndex,
		PUNIT_PROPERTY_VALUE pPropertyVaule);
HGLOBAL WINAPI GetAllPropertyData_eAgent (HUNIT hUnit);



/////////////////////////////////////////////////////////////////////////////
// CeAgent window

class CeAgent : public CWnd
{
// Construction
public:
	CeAgent();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CeAgent)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetSRModeID(CString sGUID);
	void GetSRModeID();
	void SetTTSModeID(CString sGUID);
	void GetTTSModeID();
	CString m_SRModeID;
	CString m_TTSModeID;


	BOOL GetEnabled(long dwCommandID);
	BOOL GetcVisible(long dwCommandID);
	BOOL SetEnabled(long dwCommandID,BOOL bEnabled);
	BOOL SetVisible(long dwCommandID,BOOL bEnabled);
	BOOL SetVoice(long dwCommandID,CString sCaption);
	BOOL SetCaption(long dwCommandID,CString sCaption);
	CString GetDescription();
	CString GetName();
	CString GetVoice(long dwCommandID);
	CString GetCaption(long dwCommandID);
	void Listen(BOOL bListen);
	BOOL GetAnimationNames(IUnknown ** punkEnum);
	void SetLanguageID(long dwLgId);
	void RemoveAll();
	void Remove(long dwRefID);
	long Add(CString szCaption,CString  szVoice,BOOL bEnabled,BOOL bVisible);
	long Insert(CString szCaption,CString  szVoice,BOOL bEnabled,BOOL bVisible,long dwRefID,BOOL bBefore);
	void GetAutoPopupMenu();
	void SetAutoPopupMenu();
	BOOL GetVisible();
	void ShowPopupMenu(short x,short y);
	long MoveTo(short x,short y,long lspeed);
	long Wait(long lReqID);
	void StopAll();
	void Stop(long lReqID);
	long Think(BSTR bszText);
	long Speak(BSTR bszText,CString bszURL);
	long Play(CString bszAnimation);
	long Hide();
	long Show();
	void SetSoundEffectsOn();
	void GetSoundEffectsOn();
	void SetSize();
	void GetSize();
	void SetPosition();
	void GetPosition();
	BOOL Load(CString aPath);
	void Unload();
	virtual ~CeAgent();
	CPIeAgent m_info;

	DWORD m_dwWinFormID, m_dwUnitID;
   DWORD m_dwCookie;
	BOOL m_blInDesignMode;
	// Generated message map functions
protected:


	//{{AFX_MSG(CeAgent)
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);

	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
//	DECLARE_DISPATCH_MAP()//����dispatch map��

	IAgentCharacterEx* m_pCharacterEx;
	long lCharID;
	IAgentEx* pAgentEx;

	AgentNotifySink*  pSink;
//	CWnd m_wndSink;
	long lNotifySinkID;

private:

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EAGENT_H__AAE87E0B_6B5E_4E09_8203_770FA2DF7A56__INCLUDED_)
