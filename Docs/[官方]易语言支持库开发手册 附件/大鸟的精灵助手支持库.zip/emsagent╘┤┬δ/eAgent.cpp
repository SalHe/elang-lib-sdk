// eAgent.cpp : implementation file
//

#include "stdafx.h"
#include <AFXPRIV.H>
#include "eMsAgent.h"
#include "eAgent.h"
#include "AgtSvr_i.c"


#define SAFE_RELEASE(p)		{ if(p) { (p)->Release(); (p)=NULL; } }

INT WINAPI NotifySys (INT nMsg, DWORD dwParam1, DWORD dwParam2 = 0);

#include "untshare.cpp"

extern CEMsAgentApp theApp;

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CeAgent

CeAgent::CeAgent()
{
	m_pCharacterEx=NULL;
	lCharID=-1;
	pAgentEx=NULL;
	lNotifySinkID=0;
	pSink=NULL;

}

CeAgent::~CeAgent()
{
	Unload();
	if (lNotifySinkID !=0) 
	{
		pAgentEx->Unregister(lNotifySinkID);
		lNotifySinkID=0;
		//SAFE_RELEASE(pSink);
		pSink->Release ();


	}	

	//NotifySys (NRS_DO_EVENTS,0, 0);	

	
	SAFE_RELEASE(pAgentEx);	
}


BEGIN_MESSAGE_MAP(CeAgent, CWnd)

	//{{AFX_MSG_MAP(HTMLBrowser)
	ON_WM_PAINT()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



/////////////////////////////////////////////////////////////////////////////
// CeAgent message handlers

void CeAgent::PostNcDestroy() 
{
	// TODO: Add your specialized code here and/or call the base class
	CWnd::PostNcDestroy();



	NotifySys (NRS_UNIT_DESTROIED, m_dwWinFormID, m_dwUnitID);
	delete this;
}

void CeAgent::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CWnd::OnPaint() for painting messages

	CDC* pDC=GetDC();
	CDC* pDisplayMemDC=new CDC;
	CBitmap* pBitmap = new CBitmap;
	CBrush* pBrush=new CBrush;

	CRect rect;
	GetClientRect(rect);
	pBrush->CreateSolidBrush(::GetSysColor (COLOR_BTNFACE));
	//pDC->SelectObject(pBrush);

	pDC->FillRect(rect,pBrush);
	pBrush->DeleteObject();
	delete pBrush;

	pDisplayMemDC->CreateCompatibleDC(pDC);

	pBitmap->LoadBitmap(IDB_BITMAP1);//װ��λͼ

	pDisplayMemDC->SelectObject(pBitmap);

	pDC->BitBlt(0,0,32,32,pDisplayMemDC,0,0,SRCCOPY); 

	pDisplayMemDC->DeleteDC();   
	pBitmap->DeleteObject();   
	delete pDisplayMemDC;
	delete pBitmap;
	pDC->ReleaseOutputDC();

}

void CeAgent::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	if (cx!=32 || cy!=32)
	{
		// need to push non-client borders out of the client area
		WINDOWPLACEMENT wndpl;
		GetWindowPlacement(&wndpl);

		SetWindowPos(NULL, wndpl.rcNormalPosition.left, wndpl.rcNormalPosition.top,
		32, 32, SWP_NOACTIVATE | SWP_NOZORDER);

	}	
}

BOOL CeAgent::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	if(! CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext))
		return FALSE;

	if(m_blInDesignMode)
		return TRUE;
	// Initialize COM here.
	 if (FAILED(OleInitialize(NULL))) 
		 return FALSE;//��ʼ��OLE 



	HRESULT hRes = ::CoCreateInstance(
				CLSID_AgentServer,
				NULL,
				CLSCTX_LOCAL_SERVER,
				IID_IAgentEx,
				(LPVOID*) & pAgentEx );


	if ( FAILED( hRes ) )
	{
		//DestroyWindow();
		pAgentEx=NULL;
		return TRUE;
	}



	pSink = new AgentNotifySink;

	pSink->m_dwUnitID= m_dwUnitID;
	pSink->m_dwWinFormID=m_dwWinFormID;
	pSink->AddRef();
	//�������ü���

	hRes = pAgentEx->Register((IUnknown *)pSink, &lNotifySinkID);
/*
 if(  AfxConnectionAdvise( 
    pSink,  //�����Ӷ���Ľӿ�ָ��
    IID_IAgentNotifySinkEx, //���ӽӿ�ID
    GetIDispatch(FALSE), //����Ƕ��IDispatchʵ�����һ������ʵ��m_xDispatch���˳�ȥ
    FALSE,   //donod addref
    &m_dwCookie ))
	AfxMessageBox("err");  //cookie to break connection later...*/

	return TRUE;
}




void CeAgent::Unload()
{


	SAFE_RELEASE(m_pCharacterEx);

	if ( lCharID != -1 )
	{
		pAgentEx->Unload( lCharID );		// Unload the animation data
		lCharID = -1;
	}


}

BOOL CeAgent::Load(CString aPath)
{
	if(!pAgentEx)return FALSE;
	HRESULT hRes;
	long lReqID = 0;
	VARIANT vPath;
	VariantInit(&vPath);

	if(!aPath || aPath.GetLength()<8)
		vPath.vt = VT_EMPTY;
	else
	{
		vPath.vt = VT_BSTR;
		vPath.bstrVal=aPath.AllocSysString();
	}
	hRes = pAgentEx->Load( vPath, & lCharID, & lReqID );
	VariantClear(&vPath);

	if ( FAILED( hRes ) )
		return FALSE;
		// Success load

	hRes = pAgentEx->GetCharacterEx( lCharID, & m_pCharacterEx );
	if(!lCharID)
		return FALSE;
	SetPosition();
	if(m_info.m_Height>0 && m_info.m_Width>0)
		SetSize();

	SetSoundEffectsOn();
	SetAutoPopupMenu();


	return TRUE;
		
}

void CeAgent::GetPosition()
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->GetPosition(&m_info.m_Left,&m_info.m_Top);
}

void CeAgent::SetPosition()
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->SetPosition(m_info.m_Left,m_info.m_Top);

}

void CeAgent::GetSize()
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->GetSize(&m_info.m_Width,&m_info.m_Height);

}

void CeAgent::SetSize()
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->SetSize(m_info.m_Width,m_info.m_Height);

}

void CeAgent::GetSoundEffectsOn()
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->GetSoundEffectsOn((long *)&m_info.SoundOn);
}

void CeAgent::SetSoundEffectsOn()
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->SetSoundEffectsOn(m_info.SoundOn);
}

long CeAgent::Show()
{
	if(!m_pCharacterEx)	return 0;
	long lReqID = 0;
	HRESULT hRes = m_pCharacterEx->Show( FALSE, & lReqID );
	return lReqID;
}

long CeAgent::Hide()
{
	if(!m_pCharacterEx)	return 0;
	long lReqID = 0;
	HRESULT hRes = m_pCharacterEx->Hide( FALSE, & lReqID );
	return lReqID;
}

long CeAgent::Play(CString bszAnimation)
{
	if(!m_pCharacterEx)	return 0;
	long lReqID = 0;
	BSTR b=bszAnimation.AllocSysString();
	HRESULT hRes = m_pCharacterEx->Play(b, & lReqID );
	::SysFreeString(b);
	return lReqID;
}

long CeAgent::Speak(BSTR bszText,CString bszURL)
{
	if(!m_pCharacterEx)	return 0;
	long lReqID = 0;
	BSTR bszUrl=bszURL.AllocSysString();
	//BSTR b=bszText.AllocSysString();

	HRESULT hRes = m_pCharacterEx->Speak(bszText, bszUrl,& lReqID );
		
	::SysFreeString(bszUrl);
	return lReqID;
}

long CeAgent::Think(BSTR bszText)
{
	if(!m_pCharacterEx)	return 0;
	long lReqID = 0;
	//BSTR b=bszText.AllocSysString();
	HRESULT hRes = m_pCharacterEx->Think(bszText, & lReqID );
	return lReqID;
}

void CeAgent::Stop(long lReqID)
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->Stop(lReqID );
}

void CeAgent::StopAll()
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->StopAll(1);
}

long CeAgent::Wait(long lReqID)
{
	if(!m_pCharacterEx)	return 0;
	long ReqID = 0;
	HRESULT hRes = m_pCharacterEx->Wait(lReqID, & ReqID );
	return ReqID;
}

long CeAgent::MoveTo(short x, short y, long lspeed)
{
	if(!m_pCharacterEx)	return 0;
	long lReqID = 0;
	HRESULT hRes = m_pCharacterEx->MoveTo(x,y,lspeed,&lReqID);
	return lReqID;
}

void CeAgent::ShowPopupMenu(short x, short y)
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->ShowPopupMenu(x,y);
}

BOOL CeAgent::GetVisible()
{

	if(!m_pCharacterEx)	return FALSE;
	BOOL pbVisible;
	HRESULT hRes = m_pCharacterEx->GetVisible((long *)&pbVisible);
	return pbVisible;
}
void CeAgent::SetAutoPopupMenu()
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->SetAutoPopupMenu (m_info.MenuOn);

}

void CeAgent::GetAutoPopupMenu()
{
	if(!m_pCharacterEx)	return ;
	HRESULT hRes = m_pCharacterEx->GetAutoPopupMenu ((long *)&m_info.MenuOn);

}
long CeAgent::Insert(CString szCaption,CString  szVoice,BOOL bEnabled,BOOL bVisible,long dwRefID,BOOL bBefore)
{

	long lReqID = 0;
	IAgentCommands * pAgentCommands;

	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);

	if ( FAILED( hRes ) )
	{
		return lReqID;
	}

	BSTR bszCaption=szCaption.AllocSysString();
	BSTR bszVoice=szVoice.AllocSysString();
	pAgentCommands->Insert(bszCaption,bszVoice,bEnabled,bVisible,dwRefID,bBefore,&lReqID);

	pAgentCommands->Release();
	::SysFreeString(bszCaption);
	::SysFreeString(bszVoice);

	return lReqID;
}


long CeAgent::Add(CString szCaption, CString szVoice, BOOL bEnabled, BOOL bVisible)
{
	long lReqID = 0;
	IAgentCommands * pAgentCommands;

	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);

	if ( FAILED( hRes ) )
	{
		return lReqID;
	}


	BSTR bszCaption=szCaption.AllocSysString();
	BSTR bszVoice=szVoice.AllocSysString();
	pAgentCommands->Add(bszCaption,bszVoice,bEnabled,bVisible,&lReqID);
	::SysFreeString(bszCaption);
	::SysFreeString(bszVoice);

	pAgentCommands->Release();
	return lReqID;
}


void CeAgent::Remove(long dwRefID)
{
	IAgentCommands * pAgentCommands;

	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);

	if ( FAILED( hRes ) )
	{
		return ;
	}
	pAgentCommands->Remove(dwRefID);
	pAgentCommands->Release();

}

void CeAgent::RemoveAll()
{
	IAgentCommands * pAgentCommands;

	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);

	if ( FAILED( hRes ) )
	{
		return ;
	}
	pAgentCommands->RemoveAll();
	pAgentCommands->Release();
}
void CeAgent::SetLanguageID(long dwLgId)
{
	if(!m_pCharacterEx)	return ;
	m_pCharacterEx->SetLanguageID(dwLgId);
}
BOOL CeAgent::GetAnimationNames(IUnknown **punkEnum)
{
	if(!m_pCharacterEx)	return FALSE;
	m_pCharacterEx->GetAnimationNames(punkEnum);
	return TRUE;

}
void CeAgent::Listen(BOOL bListen)
{
	if(!m_pCharacterEx)	return ;
	m_pCharacterEx->Listen(bListen);
}
CString CeAgent::GetName()
{
	CString sCaption;
	if (!m_pCharacterEx)
	{
		sCaption.Empty();
		return sCaption;
	}
	BSTR bszCaption;
	m_pCharacterEx->GetName(&bszCaption);
	sCaption=bszCaption;
	return sCaption;
}

CString CeAgent::GetDescription()
{
	CString sCaption;
	if (!m_pCharacterEx)
	{
		sCaption.Empty();
		return sCaption;
	}
	BSTR bszCaption;
	m_pCharacterEx->GetDescription(&bszCaption);
	sCaption=bszCaption;
	return sCaption;
}

CString CeAgent::GetCaption(long dwCommandID)
{
	IAgentCommands * pAgentCommands;
	IAgentCommand * pcAgentCommands;
	CString sCaption;
	if (!m_pCharacterEx)
	{
		sCaption.Empty();
		return sCaption;
	}
	IUnknown *ppunkCommand;
	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);
	if ( FAILED( hRes ) )
	{
		sCaption.Empty();
		return sCaption;
	}

	pAgentCommands->GetCommand(dwCommandID,&ppunkCommand);
	if (!ppunkCommand)
	{
		sCaption.Empty();
		return sCaption;
	}
	pAgentCommands->Release();
	hRes=ppunkCommand->QueryInterface(IID_IAgentCommand, (LPVOID*) & pcAgentCommands);
	ppunkCommand->Release();
	if ( FAILED( hRes ) )
	{
		sCaption.Empty();
		return sCaption;
	}

	BSTR bszCaption;
	pcAgentCommands->GetCaption(&bszCaption);
	pcAgentCommands->Release();

	if (!bszCaption)
	{
		sCaption.Empty();
		return sCaption;
	}

	sCaption=bszCaption;
	return sCaption;
}

CString CeAgent::GetVoice(long dwCommandID)
{
	IAgentCommands * pAgentCommands;
	IAgentCommand * pcAgentCommands;
	CString sCaption;
	if (!m_pCharacterEx)
	{
		sCaption.Empty();
		return sCaption;
	}
	IUnknown *ppunkCommand;
	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);
	if ( FAILED( hRes ) )
	{
		sCaption.Empty();
		return sCaption;
	}

	pAgentCommands->GetCommand(dwCommandID,&ppunkCommand);
	pAgentCommands->Release();
	if (!ppunkCommand)
	{
		sCaption.Empty();
		return sCaption;
	}
	hRes=ppunkCommand->QueryInterface(IID_IAgentCommand, (LPVOID*) & pcAgentCommands);
	ppunkCommand->Release();
	if ( FAILED( hRes ) )
	{
		sCaption.Empty();
		return sCaption;
	}

	BSTR bszCaption;

	pcAgentCommands->GetVoice(&bszCaption);
	pcAgentCommands->Release();

	if (!bszCaption)
	{
		sCaption.Empty();
		return sCaption;
	}
	sCaption=bszCaption;
	return sCaption;
}

BOOL CeAgent::SetCaption(long dwCommandID,CString sCaption)
{
	IAgentCommands * pAgentCommands;
	IAgentCommand * pcAgentCommands;
	
	if (!m_pCharacterEx)
	{
		return FALSE;
	}
	IUnknown *ppunkCommand;
	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);
	if ( FAILED( hRes ) )
	{
		return FALSE;
	}

	pAgentCommands->GetCommand(dwCommandID,&ppunkCommand);
	pAgentCommands->Release();
	if (!ppunkCommand)
	{

		return FALSE;
	}
	hRes=ppunkCommand->QueryInterface(IID_IAgentCommand, (LPVOID*) & pcAgentCommands);
	ppunkCommand->Release();
	if ( FAILED( hRes ) )
	{

		return FALSE;
	}

	BSTR bszCaption=sCaption.AllocSysString();

	pcAgentCommands->SetCaption(bszCaption);
	pcAgentCommands->Release();
	::SysFreeString(bszCaption);
	return TRUE;
}

BOOL CeAgent::SetVoice(long dwCommandID,CString sCaption)
{
	IAgentCommands * pAgentCommands;
	IAgentCommand * pcAgentCommands;
	
	if (!m_pCharacterEx)
	{
		return FALSE;
	}
	IUnknown *ppunkCommand;
	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);
	if ( FAILED( hRes ) )
	{
		return FALSE;
	}

	pAgentCommands->GetCommand(dwCommandID,&ppunkCommand);
	pAgentCommands->Release();
	if (!ppunkCommand)
	{

		return FALSE;
	}
	hRes=ppunkCommand->QueryInterface(IID_IAgentCommand, (LPVOID*) & pcAgentCommands);
	ppunkCommand->Release();
	if ( FAILED( hRes ) )
	{

		return FALSE;
	}

	BSTR bszCaption=sCaption.AllocSysString();

	pcAgentCommands->SetVoice(bszCaption);
	pcAgentCommands->Release();
	::SysFreeString(bszCaption);
	return TRUE;
}


BOOL CeAgent::SetEnabled(long dwCommandID,BOOL bEnabled)
{
	IAgentCommands * pAgentCommands;
	IAgentCommand * pcAgentCommands;
	
	if (!m_pCharacterEx)
	{
		return FALSE;
	}
	IUnknown *ppunkCommand;
	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);
	if ( FAILED( hRes ) )
	{
		return FALSE;
	}

	pAgentCommands->GetCommand(dwCommandID,&ppunkCommand);
	pAgentCommands->Release();
	if (!ppunkCommand)
	{

		return FALSE;
	}
	hRes=ppunkCommand->QueryInterface(IID_IAgentCommand, (LPVOID*) & pcAgentCommands);
	ppunkCommand->Release();
	if ( FAILED( hRes ) )
	{

		return FALSE;
	}



	pcAgentCommands->SetEnabled(bEnabled);
	pcAgentCommands->Release();

	return TRUE;
}
BOOL CeAgent::SetVisible(long dwCommandID,BOOL bEnabled)
{
	IAgentCommands * pAgentCommands;
	IAgentCommand * pcAgentCommands;
	
	if (!m_pCharacterEx)
	{
		return FALSE;
	}
	IUnknown *ppunkCommand;
	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);
	if ( FAILED( hRes ) )
	{
		return FALSE;
	}

	pAgentCommands->GetCommand(dwCommandID,&ppunkCommand);
	pAgentCommands->Release();
	if (!ppunkCommand)
	{

		return FALSE;
	}
	hRes=ppunkCommand->QueryInterface(IID_IAgentCommand, (LPVOID*) & pcAgentCommands);
	ppunkCommand->Release();
	if ( FAILED( hRes ) )
	{

		return FALSE;
	}



	pcAgentCommands->SetVisible(bEnabled);
	pcAgentCommands->Release();

	return TRUE;
}


BOOL CeAgent::GetEnabled(long dwCommandID)
{
	IAgentCommands * pAgentCommands;
	IAgentCommand * pcAgentCommands;
	BOOL bEnabled;
	if (!m_pCharacterEx)
	{
		return FALSE;
	}
	IUnknown *ppunkCommand;
	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);
	if ( FAILED( hRes ) )
	{
		return FALSE;
	}

	pAgentCommands->GetCommand(dwCommandID,&ppunkCommand);
	pAgentCommands->Release();
	if (!ppunkCommand)
	{

		return FALSE;
	}
	hRes=ppunkCommand->QueryInterface(IID_IAgentCommand, (LPVOID*) & pcAgentCommands);
	ppunkCommand->Release();
	if ( FAILED( hRes ) )
	{

		return FALSE;
	}



	pcAgentCommands->GetEnabled((long *)&bEnabled);
	pcAgentCommands->Release();

	return bEnabled;
}
BOOL CeAgent::GetcVisible(long dwCommandID)
{
	IAgentCommands * pAgentCommands;
	IAgentCommand * pcAgentCommands;
	BOOL bEnabled;
	if (!m_pCharacterEx)
	{
		return FALSE;
	}
	IUnknown *ppunkCommand;
	HRESULT hRes=m_pCharacterEx->QueryInterface(IID_IAgentCommands, (LPVOID*) & pAgentCommands);
	if ( FAILED( hRes ) )
	{
		return FALSE;
	}

	pAgentCommands->GetCommand(dwCommandID,&ppunkCommand);
	pAgentCommands->Release();
	if (!ppunkCommand)
	{

		return FALSE;
	}
	hRes=ppunkCommand->QueryInterface(IID_IAgentCommand, (LPVOID*) & pcAgentCommands);
	ppunkCommand->Release();
	if ( FAILED( hRes ) )
	{

		return FALSE;
	}



	pcAgentCommands->GetVisible((long *)&bEnabled);
	pcAgentCommands->Release();

	return bEnabled;
}

void CeAgent::GetTTSModeID()
{
	if(!m_pCharacterEx)	return ;
	BSTR bszCaption;
	HRESULT hRes=m_pCharacterEx->GetTTSModeID(&bszCaption);
	if ( FAILED( hRes ) )
	{
		//AfxMessageBox("error2");
		m_TTSModeID="";
		return ;
	}
	m_TTSModeID=bszCaption;
	::SysFreeString(bszCaption);

}

void CeAgent::SetTTSModeID(CString sGUID)
{
	if(!m_pCharacterEx)	return ;
	BSTR bszCaption=sGUID.AllocSysString();
	HRESULT hRes=m_pCharacterEx->SetTTSModeID(bszCaption);
	//if ( FAILED( hRes ) )AfxMessageBox("error");
	::SysFreeString(bszCaption);
}	

void CeAgent::GetSRModeID()
{
	if(!m_pCharacterEx)	return ;
	BSTR bszCaption;
	HRESULT hRes=m_pCharacterEx->GetSRModeID(&bszCaption);
	if ( FAILED( hRes ) )
	{
		//AfxMessageBox("error2");
		m_SRModeID="";
		return ;
	}
	m_SRModeID=bszCaption;
	::SysFreeString(bszCaption);

}
void CeAgent::SetSRModeID(CString sGUID)
{
	if(!m_pCharacterEx)	return ;
	BSTR bszCaption=sGUID.AllocSysString();
	HRESULT hRes=m_pCharacterEx->SetSRModeID(bszCaption);
	//if ( FAILED( hRes ) )AfxMessageBox("error");
	::SysFreeString(bszCaption);
}

/////////////////////////////////////////////////////////////////////////////
#ifndef __E_STATIC_LIB
// !!! �˴��Ķ���˳����Բ��ɸı�
static EVENT_ARG_INFO s_eAgentInfo [] =
{
//****** 
	{
/*name*/	_WT("����λ��"),
/*explain*/	_WT(""),
/*state*/	NULL,
	},
//****** 
	{
/*name*/	_WT("����λ��"),
/*explain*/	_WT(""),
/*state*/	NULL,
	},

//****** 
	{
/*name*/	_WT("���ܼ�״̬"),
/*explain*/	_WT("1��Ϊ��������2��Ϊ����Ҽ����������ܼ�������Լ��ԡ�"),
/*state*/	NULL,
	}, 
//****** 
	{
/*name*/	_WT("�������"),
/*explain*/	_WT(""),
/*state*/	NULL,
	}, 
//****** 
	{
/*name*/	_WT("����״̬"),
/*explain*/	_WT(""),
/*state*/	NULL,
	}, 
//****** 
	{
/*name*/	_WT("����״̬"),
/*explain*/	_WT(""),
/*state*/	NULL,
	}, 
//****** 
	{
/*name*/	_WT("�������"),
/*explain*/	_WT(""),
/*state*/	NULL,
	}, 
};

// !!! �˴��Ķ���˳����Բ��ɸı䣬��Ĭ����Ϣ������λ��
EVENT_INFO g_eAgentEvent [] =
{
	{
	_WT("������"),
	_WT("��������갴ť�󼴲������¼���"),
/*m_dwState*/			NULL,
/*m_nArgCount*/			3,
/*m_pBeginArgInfo*/		s_eAgentInfo ,
	}, 
	{
	_WT("������ʼ"),
	_WT("������һ��������ʼʱ�������¼���"),
/*m_dwState*/			NULL,
/*m_nArgCount*/			1,
/*m_pBeginArgInfo*/		&s_eAgentInfo[3],
	}, 
	{
	_WT("�������"),
	_WT("������Ĳ�����ɷ������¼���"),
/*m_dwState*/			NULL,
/*m_nArgCount*/			2,
/*m_pBeginArgInfo*/		&s_eAgentInfo[3],
	}, 
	{
	_WT("�յ�����"),
	_WT("���յ�Ҫ�����������ŷ������¼���һ�������Զ���Ĳ˵����"),
/*m_dwState*/			NULL,
/*m_nArgCount*/			1,
/*m_pBeginArgInfo*/		&s_eAgentInfo[3],
	}, 
	{
	_WT("�϶���ʼ"),
	_WT("�����鱻����϶�ʱ�������¼���"),
/*m_dwState*/			NULL,
/*m_nArgCount*/			3,
/*m_pBeginArgInfo*/		s_eAgentInfo ,
	}, 
	{
	_WT("�϶�����"),
	_WT("�����鱻����϶���������¼���"),
/*m_dwState*/			NULL,
/*m_nArgCount*/			3,
/*m_pBeginArgInfo*/		s_eAgentInfo ,
	}, 
	{
	_WT("���鱻˫��"),
	_WT("��˫����갴ť�󼴲������¼���"),
/*m_dwState*/			NULL,
/*m_nArgCount*/			3,
/*m_pBeginArgInfo*/		s_eAgentInfo ,
	}, 
};

INT g_eAgentEventCount = sizeof (g_eAgentEvent) / sizeof (g_eAgentEvent [0]);


// ע��˳�򲻿ɸı�!!!
UNIT_PROPERTY g_eAgentProperty [] =
{
	FIXED_WIN_UNIT_PROPERTY,
	{
	/*m_szName*/			_WT("���鶥��"),
	/*m_szEgName*/			_WT("Top"),
	/*m_szExplain*/			_WT("ָ���������λ�õĶ��ߡ�"),
	/*m_shtType*/			UD_INT,
	/*m_wState*/			NULL,
	/*m_szzPickStr*/		NULL,
	}, 	{
	/*m_szName*/			_WT("�������"),
	/*m_szEgName*/			_WT("Left"),
	/*m_szExplain*/			_WT("ָ���������λ�õ���ߡ�"),
	/*m_shtType*/			UD_INT,
	/*m_wState*/			NULL,
	/*m_szzPickStr*/		NULL,
	}, {
	/*m_szName*/			_WT("�������"),
	/*m_szEgName*/			_WT("Width"),
	/*m_szExplain*/			_WT("ָ��������ȡ�0Ϊʹ��Ĭ��ֵ"),
	/*m_shtType*/			UD_INT,
	/*m_wState*/			NULL,
	/*m_szzPickStr*/		NULL,
	}, {
	/*m_szName*/			_WT("����߶�"),
	/*m_szEgName*/			_WT("Height"),
	/*m_szExplain*/			_WT("ָ������߶ȡ�0Ϊʹ��Ĭ��ֵ"),
	/*m_shtType*/			UD_INT,
	/*m_wState*/			NULL,
	/*m_szzPickStr*/		NULL,
	}, {
	/*m_szName*/			_WT("����"),
	/*m_szEgName*/			_WT("SoundEffectsOff"),
	/*m_szExplain*/			_WT("�رվ��鷢��������"),
	/*m_shtType*/			UD_BOOL,
	/*m_wState*/			NULL,
	/*m_szzPickStr*/		NULL,
	}, {
	/*m_szName*/			_WT("�������"),
	/*m_szEgName*/			_WT("Visible"),
	/*m_szExplain*/			_WT("���鵱ǰ�Ƿ���ӡ�"),
	/*m_shtType*/			UD_BOOL,
	/*m_wState*/			UW_ONLY_READ,
	/*m_szzPickStr*/		NULL,
	}, {
	/*m_szName*/			_WT("�˵���ֹ"),
	/*m_szEgName*/			_WT("NoMenu"),
	/*m_szExplain*/			_WT("����Ĳ˵��Ƿ���ã���ֹ���������ԵĲ˵���"),
	/*m_shtType*/			UD_BOOL,
	/*m_wState*/			NULL,
	/*m_szzPickStr*/		NULL,
	},{
	/*m_szName*/			_WT("TTS����ID"),
	/*m_szEgName*/			_WT("TTSModeID"),
	/*m_szExplain*/			_WT("����ʹ�����������ʶ�����������GUID��"),
	/*m_shtType*/			UD_TEXT,
	/*m_wState*/			UW_CANNOT_INIT,
	/*m_szzPickStr*/		NULL,
	},{
	/*m_szName*/			_WT("����ʶ������ID"),
	/*m_szEgName*/			_WT("SRModeID"),
	/*m_szExplain*/			_WT("����ʹ����������ʶ�����������GUID��"),
	/*m_shtType*/			UD_TEXT,
	/*m_wState*/			UW_CANNOT_INIT,
	/*m_szzPickStr*/		NULL,
	},

};

INT g_eAgentPropertyCount = sizeof (g_eAgentProperty) / sizeof (g_eAgentProperty [0]);

#endif

///////////////////////////////////////////////////

void CPIeAgent::init ()
{
	CPropertyInfo::init ();

	m_Top=0;
	m_Left=0;
	m_Width=0;
	m_Height=0;
    SoundOn=TRUE;
	MenuOn=TRUE;

}

BOOL CPIeAgent::Serialize (CArchive& ar)
{
	if (CPropertyInfo::Serialize (ar) == FALSE)
		return FALSE;

	TRY
	{
		if (ar.IsLoading () == TRUE)
		{
			DWORD dwUnitDataVer;
			ar >> dwUnitDataVer;
			if (dwUnitDataVer > CUR_UNIT_VER)
				return FALSE;
			ar >> m_Top >> m_Left >> m_Width >> m_Height >> SoundOn >> MenuOn;
		}
		else
		{
			ar << (DWORD)CUR_UNIT_VER;
			ar << m_Top << m_Left << m_Width << m_Height << SoundOn << MenuOn;
		}


		return TRUE;
	}
	END_TRY

	return FALSE;
}

/////////////////////////////////////////////////////////////////////////////

HUNIT WINAPI Create_eAgent (LPBYTE pAllData, INT nAllDataSize,
		DWORD dwStyle, HWND hParentWnd, UINT uID, HMENU hMenu, INT x, INT y, INT cx, INT cy,
		DWORD dwWinFormID, DWORD dwUnitID, HWND hDesignWnd, BOOL blInDesignMode)
{
	CeAgent* pUnit = new CeAgent;

	if (pUnit->m_info.LoadData (pAllData, nAllDataSize) == FALSE)
	{
		delete pUnit;
		return NULL;
	}

	pUnit->m_dwWinFormID = dwWinFormID;
	pUnit->m_dwUnitID = dwUnitID;
	pUnit->m_blInDesignMode = blInDesignMode;



	RECT rect={x, y, x+cx, y+cy};

	if (pUnit->Create (AfxRegisterWndClass (CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW,
			::LoadCursor (NULL, IDC_ARROW), HBRUSH (::GetStockObject (::GetSysColor (COLOR_BTNFACE)))),NULL, dwStyle | WS_CHILD | WS_CLIPSIBLINGS ,
		rect,CWnd::FromHandle(hParentWnd),uID))
	{


		return (HUNIT)pUnit;
	}
	else
		return NULL;
}

BOOL WINAPI NotifyPropertyChanged_eAgent (HUNIT hUnit, INT nPropertyIndex,
											  PUNIT_PROPERTY_VALUE pPropertyVaule,
											  LPTSTR* ppszTipText)
{
	ASSERT (hUnit != NULL);
	if (hUnit == NULL)  return FALSE;
	CeAgent* pUnit = (CeAgent*)hUnit;
	ASSERT (pUnit->GetSafeHwnd () != NULL);

	if (ppszTipText != NULL)
		*ppszTipText = NULL;

// ע��˴��������������������Ա���ȫһ�¡�
	switch (nPropertyIndex)
	{
	case 0:

		pUnit->m_info.m_Top =pPropertyVaule->m_int;
		if(!pUnit->m_blInDesignMode)
			pUnit->SetPosition();
		break;
	case 1:

		pUnit->m_info.m_Left =pPropertyVaule->m_int;
		if(!pUnit->m_blInDesignMode)
			pUnit->SetPosition();		
		break;
	case 2:
		pUnit->m_info.m_Width =pPropertyVaule->m_int;
		if(!pUnit->m_blInDesignMode)
			pUnit->SetSize();
		break;
	case 3:
		pUnit->m_info.m_Height =pPropertyVaule->m_int;
		if(!pUnit->m_blInDesignMode)
			pUnit->SetSize();
		break;
	case 4:
		pUnit->m_info.SoundOn = !pPropertyVaule->m_bool;
		if(!pUnit->m_blInDesignMode)
			pUnit->SetSoundEffectsOn ();
		break;
	case 6:
		pUnit->m_info.MenuOn = !pPropertyVaule->m_bool;
		if(!pUnit->m_blInDesignMode)
			pUnit->SetAutoPopupMenu();
		break;
	case 7:
		if(!pUnit->m_blInDesignMode)
			pUnit->SetTTSModeID(pPropertyVaule->m_szText);
		break;
	case 8:
		if(!pUnit->m_blInDesignMode)
			pUnit->SetSRModeID(pPropertyVaule->m_szText);
		break;
    default:
        ASSERT (FALSE);
        break;
	}

	return FALSE;
}

// !! ��������ʱ���ܱ��û������ı䣨������ֱ�ӵ���API�����������ԣ�������ʱ����ȡ������ʵ��ֵ��
BOOL WINAPI GetPropertyData_eAgent (HUNIT hUnit, INT nPropertyIndex,
										PUNIT_PROPERTY_VALUE pPropertyVaule)
{
	ASSERT (hUnit != NULL);
	if (hUnit == NULL)  return FALSE;
	CeAgent* pUnit = (CeAgent*)hUnit;
	ASSERT (pUnit->GetSafeHwnd () != NULL);

// ע��˴��������������������Ա���ȫһ�¡�
	switch (nPropertyIndex)
	{
	case 0:

		if(!pUnit->m_blInDesignMode)
			pUnit->GetPosition();
		pPropertyVaule->m_int=pUnit->m_info.m_Top ;
		break;
	case 1:

		if(!pUnit->m_blInDesignMode)
			pUnit->GetPosition();
		pPropertyVaule->m_int=pUnit-> m_info.m_Left ;
		break;
	case 2:
		if(!pUnit->m_blInDesignMode)
			pUnit->GetSize ();
		pPropertyVaule->m_int=pUnit-> m_info.m_Width ;
		break;
	case 3:
		if(!pUnit->m_blInDesignMode)
			pUnit->GetSize ();
		pPropertyVaule->m_int=pUnit-> m_info.m_Height ;
		break;
	case 4:

		if(!pUnit->m_blInDesignMode)
			pUnit->GetSoundEffectsOn ();
			
		pPropertyVaule->m_bool=!pUnit->m_info.SoundOn;
		break;
	case 5:
	
		pPropertyVaule->m_bool=pUnit->GetVisible ();
		break;
	case 6:
		if(!pUnit->m_blInDesignMode)
			pUnit->GetAutoPopupMenu();
			
		pPropertyVaule->m_bool=!pUnit->m_info.MenuOn;
		break;
	case 7:
		if(!pUnit->m_blInDesignMode)
			pUnit->GetTTSModeID();
			
		pPropertyVaule->m_szText=(LPTSTR)(LPCTSTR)pUnit->m_TTSModeID;
		break;
	case 8:
		if(!pUnit->m_blInDesignMode)
			pUnit->GetSRModeID();
			
		pPropertyVaule->m_szText=(LPTSTR)(LPCTSTR)pUnit->m_SRModeID;
		break;
	default:
		ASSERT (FALSE);
		return FALSE;
	}

	return TRUE;
}

HGLOBAL WINAPI GetAllPropertyData_eAgent (HUNIT hUnit)
{
	ASSERT (hUnit != NULL);
	return ((CeAgent*)hUnit)->m_info.SaveData ();
}

extern "C"
PFN_INTERFACE WINAPI emsagent_GetInterface_eMsAgent (INT nInterfaceNO)
{
	return nInterfaceNO == ITF_CREATE_UNIT ? (PFN_INTERFACE)Create_eAgent :
			nInterfaceNO == ITF_NOTIFY_PROPERTY_CHANGED ? (PFN_INTERFACE)NotifyPropertyChanged_eAgent:
			nInterfaceNO == ITF_GET_ALL_PROPERTY_DATA ? (PFN_INTERFACE)GetAllPropertyData_eAgent :
			nInterfaceNO == ITF_GET_PROPERTY_DATA ? (PFN_INTERFACE)GetPropertyData_eAgent :
			NULL;
}



//-------------------------------------------
// IUnknown methods
//-------------------------------------------

STDMETHODIMP AgentNotifySink::QueryInterface (REFIID riid, LPVOID *ppv)
{
    *ppv = NULL;



    if ((riid == IID_IUnknown) || (riid == IID_IAgentNotifySinkEx))
        *ppv = this;

    if (*ppv == NULL)
        return E_NOINTERFACE;

    ((LPUNKNOWN)*ppv)->AddRef();

    return NOERROR;
}


STDMETHODIMP_ (ULONG) AgentNotifySink::AddRef()
{
	return ++m_cRefs;
}


STDMETHODIMP_(ULONG) AgentNotifySink::Release()
{
	if (--m_cRefs != 0)
		return m_cRefs;

	delete this;
	return 0;
}

//-------------------------------------------
// IDispatch methods
//-------------------------------------------

STDMETHODIMP AgentNotifySink::GetTypeInfoCount(UINT *pctInfo)
{
    *pctInfo = 1;
    return NOERROR;
}


STDMETHODIMP AgentNotifySink::GetTypeInfo(UINT itInfo, LCID lcid, ITypeInfo **ppTypeInfo)
{
    HRESULT hRes;
    ITypeLib *pLib;

    *ppTypeInfo = NULL;

	if (itInfo != 0)
        return TYPE_E_ELEMENTNOTFOUND;

    if (ppTypeInfo == NULL)
        return E_POINTER;

	if ((PRIMARYLANGID(lcid) != LANG_NEUTRAL) && 
		(PRIMARYLANGID(lcid) != LANG_ENGLISH))
		return DISP_E_UNKNOWNLCID;

    hRes = LoadRegTypeLib(LIBID_AgentServerObjects, 
						  1, 
						  0,
						  PRIMARYLANGID(lcid), 
						  &pLib);
    if (FAILED(hRes))
        return hRes;

	hRes = pLib->GetTypeInfoOfGuid(IID_IAgentNotifySink, ppTypeInfo);
        
	pLib->Release();

    if (FAILED(hRes))
        return hRes;

    (*ppTypeInfo)->AddRef();

    return NOERROR;
}


STDMETHODIMP AgentNotifySink::GetIDsOfNames(REFIID riid, OLECHAR **rgszNames, UINT cNames, LCID lcid, DISPID *rgDispID)
{
    HRESULT hRes;
    ITypeInfo *pInfo;

	// REFIID must be NULL

	if (riid != IID_NULL)
        return ResultFromScode(DISP_E_UNKNOWNINTERFACE);

	// Get the TypeInfo for the specified lcid

    hRes = GetTypeInfo(0, lcid, &pInfo);

	if (FAILED(hRes))
		return hRes;

	// Use the TypeInfo to get the DISPIDs of the specified names.
	// That's the whole point here.  Let TypeInfo do the work so
	// we don't have to.

	hRes = pInfo->GetIDsOfNames(rgszNames, cNames, rgDispID);

	pInfo->Release();

    return hRes;
}


STDMETHODIMP AgentNotifySink::Invoke(DISPID dispID, REFIID riid, LCID lcid, 
									 unsigned short wFlags, DISPPARAMS *pDispParams, 
									 VARIANT *pVarResult, EXCEPINFO *pExcepInfo, 
									 UINT *puArgErr)
{
	HRESULT hRes;
	ITypeInfo *pInfo;

    // The riid parameter is always supposed to be IID_NULL

	if (riid != IID_NULL)
        return DISP_E_UNKNOWNINTERFACE;

	// Get the type info for the specified lcid

    hRes = GetTypeInfo(0, lcid, &pInfo);

    if (FAILED(hRes))
        return hRes;

    // Clear exceptions

    SetErrorInfo(0L, NULL);

	hRes = pInfo->Invoke(this, 
						 dispID, 
						 wFlags, 
						 pDispParams, 
						 pVarResult, 
						 pExcepInfo, 
						 puArgErr);


    pInfo->Release();

    return hRes;
}

//-------------------------------------------
// AgentNotifySink methods
//-------------------------------------------

STDMETHODIMP AgentNotifySink::Command(long dwCommandID, IUnknown * punkUserInput)
{
	EVENT_NOTIFY event (m_dwWinFormID, m_dwUnitID, 3);
	event.m_nArgCount = 1;
	event.m_nArgValue [0] = dwCommandID;
	NotifySys (NRS_EVENT_NOTIFY, (DWORD)&event);

	return NOERROR;
}


STDMETHODIMP AgentNotifySink::ActivateInputState(long dwCharID, long bActivated)
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::Restart()
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::Shutdown()
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::VisibleState(long dwCharID, long bVisible, long lCause)
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::Click(long dwCharID, short fwKeys, long x, long y)
{
	EVENT_NOTIFY event (m_dwWinFormID, m_dwUnitID, 0);
	event.m_nArgCount = 3;
	event.m_nArgValue [0] = x;
	event.m_nArgValue [1] = y;
	event.m_nArgValue [2] = fwKeys;
	NotifySys (NRS_EVENT_NOTIFY, (DWORD)&event);

	return NOERROR;
}


STDMETHODIMP AgentNotifySink::DblClick(long dwCharID, short fwKeys, long x, long y)
{

	EVENT_NOTIFY event (m_dwWinFormID, m_dwUnitID, 6);
	event.m_nArgCount = 3;
	event.m_nArgValue [0] = x;
	event.m_nArgValue [1] = y;
	event.m_nArgValue [2] = fwKeys;
	NotifySys (NRS_EVENT_NOTIFY, (DWORD)&event);
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::DragStart(long dwCharID, short fwKeys, long x, long y)
{
	EVENT_NOTIFY event (m_dwWinFormID, m_dwUnitID, 4);
	event.m_nArgCount = 3;
	event.m_nArgValue [0] = x;
	event.m_nArgValue [1] = y;
	event.m_nArgValue [2] = fwKeys;
	NotifySys (NRS_EVENT_NOTIFY, (DWORD)&event);
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::DragComplete(long dwCharID, short fwKeys, long x, long y)
{
	EVENT_NOTIFY event (m_dwWinFormID, m_dwUnitID, 5);
	event.m_nArgCount = 3;
	event.m_nArgValue [0] = x;
	event.m_nArgValue [1] = y;
	event.m_nArgValue [2] = fwKeys;
	NotifySys (NRS_EVENT_NOTIFY, (DWORD)&event);
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::RequestStart(long dwRequestID)
{
	EVENT_NOTIFY event (m_dwWinFormID, m_dwUnitID, 1);
	event.m_nArgCount = 1;
	event.m_nArgValue [0] = dwRequestID;
	NotifySys (NRS_EVENT_NOTIFY, (DWORD)&event);
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::RequestComplete(long dwRequestID, long hrStatus)
{
	EVENT_NOTIFY event (m_dwWinFormID, m_dwUnitID, 2);
	event.m_nArgCount = 2;
	event.m_nArgValue [0] = dwRequestID;
	event.m_nArgValue [1] = hrStatus;
	NotifySys (NRS_EVENT_NOTIFY, (DWORD)&event);
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::BookMark(long dwBookMarkID)
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::Idle(long dwCharID, long bStart)
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::Move(long dwCharID, long x, long y, long lCause)
{
#if defined TIP || defined BALLOONINPUT
	try 
	{
		POINT point = m_pAgent->GetPosition( dwCharID  );
		SIZE size = m_pAgent->GetSize( dwCharID  );
		CRect rectAgent ( point.x, point.y, point.x + size.cx, point.y + size.cy );
#ifdef TIP
		m_pAgent->GetTip( dwCharID )->Move ( rectAgent );
#endif
#ifdef BALLOONINPUT
		m_pAgent->GetInputBalloon( dwCharID )->Move ( rectAgent );
#endif 

	}
	catch (int* pErr)
	{
		delete pErr;
	}
#endif
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::Size(long dwCharID, long lWidth, long lHeight)
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::BalloonVisibleState(long dwCharID, long bVisible)
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::HelpComplete(long dwCharID, long dwCommandID, long dwCause)
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::ListeningState(long dwCharacterID, long bListenState, long dwCause)
{

	return NOERROR;
}


STDMETHODIMP AgentNotifySink::DefaultCharacterChange(BSTR bszGUID)
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::AgentPropertyChange()
{
	return NOERROR;
}


STDMETHODIMP AgentNotifySink::ActiveClientChange(long dwCharID, long lStatus)
{
	return NOERROR;
}




